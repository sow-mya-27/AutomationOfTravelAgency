Spring and Hibernate for Beginners -- CRUD Database Example
=======================================================

This directory contains the source code and SQL scripts for the Spring and Hibernate CRUD example.


